﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using System.Net;
using JupiterWeather.Models;


namespace JupiterWeather.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
   
        //My Code

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        string APIkey = "e473cce3c5e16a69fa535ee1fd52355f";
        private void SubmitClick(object sender, EventArgs e)
        {


            void getWeather()
            {


                using (WebClient web = new WebClient())
                {
                    string city = cityText.Text;
                    double lat = -23.55;
                    double lon = -46.63;

                    string url = string.Format("https://api.openweathermap.org/data/2.5/weather?lat={0}&lon={1}&appid={2}", lat, lon, APIkey);
                    var json = web.DownloadString(url);
                    WeatherInfo.root Info = JsonConvert.DeserializeObject<WeatherInfo.root>(json);
                    labConditions.Content = Info.weather[0].main;
                    labDetails.Content = Info.weather[0].description;
                    labSunset.Content = Info.sys.sunset.ToString();
                    labSunrise.Content = Info.sys.sunrise.ToString();
                    labWindSpeed.Content = Info.wind.speed.ToString();

                }
            }
        }
    }
    
  }

