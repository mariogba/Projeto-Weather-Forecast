﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace JupiterWeather.Models
{
    public class City
    {
        public long CityId { get; set; }
        
        public long lat { get; set; }

        public string Name { get; set; }    
        public long lon { get; set; }
    }
}
